#include "File_ShopList.h"

File_Shop_list::File_Shop_list(const std::string & filename)
{
	this->filename = filename;
}
