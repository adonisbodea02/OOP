#pragma once
#include "Repository.h"

class Controller
{
private:
	Repository repo;

public:
	Controller(const Repository& r) : repo{ r } {}

	Repository get_repo() const { return repo; }

	int add_rock_tshirt_ctrl(Rock_Tshirt& rt);

	int delete_rock_tshirt_ctrl(int id);

	int update_rock_thsirt_size_ctrl(int id, std::string& new_size);

	int update_rock_tshirt_colour_ctrl(int id, std::string& new_colour);

	int update_rock_thsirt_photo_ctrl(int id, std::string& new_photo);

	int update_rock_thsirt_price_ctrl(int id, int new_price);

	int update_rock_thsirt_quantity_ctrl(int id, int new_quantity);

	dynamic_vector<Rock_Tshirt> filter_by_size(const std::string size);
};