#pragma once
#include <iostream>

class Rock_Tshirt
{
private:
	int ID;
	std::string size;
	std::string colour;
	int quantity;
	int price;
	std::string photo;
	std::string formation;

public:
	Rock_Tshirt();

	Rock_Tshirt(const int ID, const std::string& size, const std::string& colour, int quantity, int price, const std::string& photo, const std::string& formation);

	int operator==(const Rock_Tshirt& rt);

	int get_ID() const { return ID; }
	std::string get_size() { return size; }
	std::string get_colour() { return colour; }
	int get_price() const { return price; }
	int get_quantity() { return quantity; }
	std::string get_photo() { return photo; }
	std::string get_formation() { return formation; }
	void set_size(std::string s) { size = s; }
	void set_colour(std::string c) { colour = c; }
	void set_quantity(int q) { quantity = q; }
	void set_price(int p) { price = p; }
	void set_photo(std::string p) { photo = p; }
	void set_formation(std::string f) { formation = f; }
	void display();
};