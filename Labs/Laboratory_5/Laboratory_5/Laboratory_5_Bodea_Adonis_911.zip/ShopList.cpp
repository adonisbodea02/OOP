#include "ShopList.h"

Shop_list::Shop_list()
{
	this->current = 0;
}

void Shop_list::set_tshirts(const dynamic_vector<Rock_Tshirt> dv)
{
	this->tshirts = dv;
}

Rock_Tshirt Shop_list::get_current_tshirt()
{
	if (this->current == this->tshirts.get_size())
		this->current = 0;
	Rock_Tshirt* rts = this->tshirts.get_all_elems();
	if (rts != NULL)
		return rts[this->current];
}

Rock_Tshirt Shop_list::next()
{
	if (this->tshirts.get_size() == 0)
		return Rock_Tshirt{};
	this->current++;
	Rock_Tshirt rt = this->get_current_tshirt();
	rt.display();
	return rt;
}

bool Shop_list::is_empty()
{
	return this->tshirts.get_size() == 0;
}