#include "Controller.h"

int Controller::add_rock_tshirt_ctrl(Rock_Tshirt& rt) 
{
	return this->repo.add_rock_tshirt(rt);
}

int Controller::delete_rock_tshirt_ctrl(int id)
{
	return this->repo.delete_rock_thsirt(id);
}

int Controller::update_rock_thsirt_size_ctrl(int id, std::string& new_size)
{
	return this->repo.update_rock_thsirt_size(id, new_size);
}

int Controller::update_rock_tshirt_colour_ctrl(int id, std::string& new_colour)
{
	return this->repo.update_rock_thsirt_colour(id, new_colour);
}

int Controller::update_rock_thsirt_photo_ctrl(int id, std::string& new_photo)
{
	return this->repo.update_rock_thsirt_photo(id, new_photo);
}

int Controller::update_rock_thsirt_price_ctrl(int id, int new_price)
{
	return this->repo.update_rock_thsirt_price(id, new_price);
}

int Controller::update_rock_thsirt_quantity_ctrl(int id, int new_quantity)
{
	return this->repo.update_rock_thsirt_quantity(id, new_quantity);
}

dynamic_vector<Rock_Tshirt> Controller::filter_by_size(const std::string size)
{
	dynamic_vector<Rock_Tshirt> dv = this->repo.get_rock_tshirts();
	dynamic_vector<Rock_Tshirt> dv2;
	Rock_Tshirt rt;
	int i = 0;
	while (i < dv.get_size())
	{
		rt = dv.get_element(i);
		if (rt.get_size() == size)
			dv2.add(rt);
		i++;
	}
	return dv2;
}