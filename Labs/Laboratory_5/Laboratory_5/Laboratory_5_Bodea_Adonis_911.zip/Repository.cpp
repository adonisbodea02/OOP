#include "Repository.h"
#include <string>

using namespace std;

int Repository::find_by_id(int id)
{
	Rock_Tshirt* rock_thsirts_in_array = this->rock_tshirts.get_all_elems();
	if (rock_thsirts_in_array == NULL)
		return -2;

	for (int i = 0; i < this->rock_tshirts.get_size(); i++)
	{
		Rock_Tshirt rt = rock_thsirts_in_array[i];
		if (rt.get_ID()== id)
			return i;
	}

	return -1;
}

int Repository::add_rock_tshirt(Rock_Tshirt& rt)
{
	int res = this->find_by_id(rt.get_ID());
	if (res == -1)
	{
		this->rock_tshirts.add(rt);
		return 1;
	}
	return 0;
}

int Repository::delete_rock_thsirt(int id)
{
	int res = this->find_by_id(id);
	if (res >= 0)
	{
		this->rock_tshirts.delete_element(res);
		return 1;
	}
	return 0;
}

int Repository::update_rock_thsirt_size(int id, std::string& new_size)
{
	Rock_Tshirt* rock_thsirts_in_array = this->rock_tshirts.get_all_elems();
	int res = this->find_by_id(id);
	if (res >= 0)
	{
		rock_thsirts_in_array[res].set_size(new_size);
		return 1;
	}
	return 0;
}

int Repository::update_rock_thsirt_colour(int id, std::string& new_colour)
{
	Rock_Tshirt* rock_thsirts_in_array = this->rock_tshirts.get_all_elems();
	int res = this->find_by_id(id);
	if (res >= 0)
	{
		rock_thsirts_in_array[res].set_colour(new_colour);
		return 1;
	}
	return 0;
}

int Repository::update_rock_thsirt_photo(int id, std::string& new_photo)
{
	Rock_Tshirt* rock_thsirts_in_array = this->rock_tshirts.get_all_elems();
	int res = this->find_by_id(id);
	if (res >= 0)
	{
		rock_thsirts_in_array[res].set_photo(new_photo);
		return 1;
	}
	return 0;
}

int Repository::update_rock_thsirt_price(int id, int new_price)
{
	Rock_Tshirt* rock_thsirts_in_array = this->rock_tshirts.get_all_elems();
	int res = this->find_by_id(id);
	if (res >= 0)
	{
		rock_thsirts_in_array[res].set_price(new_price);
		return 1;
	}
	return 0;
}

int Repository::update_rock_thsirt_quantity(int id, int new_quantity)
{
	Rock_Tshirt* rock_thsirts_in_array = this->rock_tshirts.get_all_elems();
	int res = this->find_by_id(id);
	if (res >= 0)
	{
		rock_thsirts_in_array[res].set_quantity(new_quantity);
		return 1;
	}
	return 0;
}

