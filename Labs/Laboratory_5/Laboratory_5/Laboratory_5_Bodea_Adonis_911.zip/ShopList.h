#pragma once
#include "Domain.h"
#include "Dynamic_Vector.h"

class Shop_list
{
private:
	dynamic_vector<Rock_Tshirt> tshirts;
	int current;

public:
	Shop_list();

	void set_tshirts(const dynamic_vector<Rock_Tshirt> dv);

	Rock_Tshirt get_current_tshirt();

	Rock_Tshirt next();

	bool is_empty();
};