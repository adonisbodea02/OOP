#include "Controller.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

MedCtrl* create_ctrl(MedRepo* repo) {
	MedCtrl* ctrl = (MedCtrl*)malloc(sizeof(MedCtrl));
	ctrl->repo = repo;
	return ctrl;
}

void delete_ctrl(MedCtrl* ctrl) {
	delete_repo(ctrl->repo);
	free(ctrl);
}

MedRepo* filter(MedCtrl* ctrl, char String[]) {

	MedRepo* temp_repo = create_repo();
	for (int i = 0; i < ctrl->repo->length; i++)
		if (strstr(ctrl->repo->vect[i]->name, String) != NULL)
			add_med_repo(temp_repo, ctrl->repo->vect[i]);

	int pos = 0;
	Medication* temp;
	while(pos < get_length_repo(temp_repo))
	{
		if (pos == 0 || strcmp(temp_repo->vect[pos]->name, temp_repo->vect[pos - 1]->name) > 0)
			pos = pos + 1;
		else
		{
			temp = temp_repo->vect[pos];
			temp_repo->vect[pos] = temp_repo->vect[pos - 1];
			temp_repo->vect[pos - 1] = temp;

			pos = pos - 1;
		}
	}
	return temp_repo;
}

MedRepo* filter_price(MedCtrl* ctrl, int price) {

	MedRepo* temp_repo = create_repo();
	for (int i = 0; i < ctrl->repo->length; i++)
		if (ctrl->repo->vect[i]->price == price)
			add_med_repo(temp_repo, ctrl->repo->vect[i]);

	int pos = 0;
	Medication* temp;
	while (pos < get_length_repo(temp_repo))
	{
		if (pos == 0 || strcmp(temp_repo->vect[pos]->name, temp_repo->vect[pos - 1]->name) > 0)
			pos = pos + 1;
		else
		{
			temp = temp_repo->vect[pos];
			temp_repo->vect[pos] = temp_repo->vect[pos - 1];
			temp_repo->vect[pos - 1] = temp;

			pos = pos - 1;
		}
	}
	return temp_repo;
}

MedRepo* short_supply(MedCtrl* ctrl, int quantity, int kind) {

	MedRepo* temp_repo = create_repo();
	for (int i = 0; i < ctrl->repo->length; i++)
		if (ctrl->repo->vect[i]->quantity < quantity)
			add_med_repo(temp_repo, ctrl->repo->vect[i]);

	int pos = 0;
	Medication* temp;
	if(kind == 1)
		while (pos < get_length_repo(temp_repo))
		{
			if (pos == 0 || (temp_repo->vect[pos]->quantity > temp_repo->vect[pos - 1]->quantity))
				pos = pos + 1;
			else
			{
				temp = temp_repo->vect[pos];
				temp_repo->vect[pos] = temp_repo->vect[pos - 1];
				temp_repo->vect[pos - 1] = temp;

				pos = pos - 1;
			}
		}
	else
		while (pos < get_length_repo(temp_repo))
		{
			if (pos == 0 || (temp_repo->vect[pos]->quantity < temp_repo->vect[pos - 1]->quantity))
				pos = pos + 1;
			else
			{
				temp = temp_repo->vect[pos];
				temp_repo->vect[pos] = temp_repo->vect[pos - 1];
				temp_repo->vect[pos - 1] = temp;

				pos = pos - 1;
			}
		}

	return temp_repo;
}

void tests_controller() {
	test_filter();
	test_filter_price();
	test_short_supply();
}

void test_filter() {
	MedRepo* repo = create_repo();
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	Medication* medication2;
	medication2 = create_medication("Ibuprofen", 5, 6, 8);
	Medication* medication3;
	medication3 = create_medication("Xanax", 19, 67, 5);
	Medication* medication4;
	medication4 = create_medication("Brufen", 12, 55, 7);
	add_med_repo(repo, medication);
	add_med_repo(repo, medication2);
	add_med_repo(repo, medication3);
	add_med_repo(repo, medication4);
	MedCtrl* ctrl = create_ctrl(repo);
	MedRepo* repo2 = filter(ctrl, "fen");
	assert(get_length_repo(repo2) == 3);
	int i = 0;
	for (i = 1; i < get_length_repo(repo2); i++)
		assert(strcmp(repo2->vect[i]->name, repo2->vect[i - 1]->name) > 0);
	free(repo2);
	delete_ctrl(ctrl);
}

void test_filter_price() {
	MedRepo* repo = create_repo();
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	Medication* medication2;
	medication2 = create_medication("Ibuprofen", 5, 6, 8);
	Medication* medication3;
	medication3 = create_medication("Xanax", 19, 67, 5);
	Medication* medication4;
	medication4 = create_medication("Brufen", 12, 55, 7);
	add_med_repo(repo, medication);
	add_med_repo(repo, medication2);
	add_med_repo(repo, medication3);
	add_med_repo(repo, medication4);
	MedCtrl* ctrl = create_ctrl(repo);
	MedRepo* repo2 = filter_price(ctrl, 7);
	assert(get_length_repo(repo2) == 2);
	free(repo2);
	delete_ctrl(ctrl);
}

void test_short_supply() {
	MedRepo* repo = create_repo();
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	Medication* medication2;
	medication2 = create_medication("Ibuprofen", 5, 6, 8);
	Medication* medication3;
	medication3 = create_medication("Xanax", 19, 67, 5);
	Medication* medication4;
	medication4 = create_medication("Brufen", 12, 55, 7);
	add_med_repo(repo, medication);
	add_med_repo(repo, medication2);
	add_med_repo(repo, medication3);
	add_med_repo(repo, medication4);
	MedCtrl* ctrl = create_ctrl(repo);
	MedRepo* repo2 = short_supply(ctrl, 60, 1);
	assert(get_length_repo(repo2) == 3);
	int i = 0;
	for (i = 1; i < get_length_repo(repo2); i++)
		assert(repo2->vect[i]->quantity > repo2->vect[i - 1]->quantity);
	free(repo2);
	repo2 = short_supply(ctrl, 10, 2);
	assert(get_length_repo(repo2) == 2);
	for (i = 1; i < get_length_repo(repo2); i++)
		assert(repo2->vect[i]->quantity < repo2->vect[i - 1]->quantity);
	free(repo2);
	delete_ctrl(ctrl);
}