#include <stdio.h>
#include <Windows.h>
#include <crtdbg.h>
#include "Domain.h"
#include "Repo.h"
#include "Controller.h"
#include "UI.h"

int main()
{
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	//printf("%s %d %d %d \n", get_name(medication), get_concentration(medication), get_quantity(medication), get_price(medication));

	//delete_medication(medication);
	Medication* medication2;
	medication2 = create_medication("Ibuprofen", 5, 6, 8);

	Medication* medication3;
	medication3 = create_medication("Xanax", 19, 67, 5);

	MedRepo* repo = create_repo();

	add_med_repo(repo, medication);
	print_repo(repo);
	printf("\n");

	add_med_repo(repo, medication2);
	print_repo(repo);
	printf("\n");

	add_med_repo(repo, medication3);
	print_repo(repo);
	printf("\n");

	printf("%d\n", get_length_repo(repo));
	printf("\n");

	delete_med_repo(repo, "Nurofen", 12);
	print_repo(repo);
	printf("\n");

	printf("%d\n", get_length_repo(repo));
	printf("\n");

	delete_med_repo(repo, "Ibuprofen", 3);
	print_repo(repo);
	printf("\n");

	printf("%d\n", get_length_repo(repo));
	printf("\n");

	update_med_quantity_repo(repo, "Ibuprofen", 5, 24);
	print_repo(repo);
	printf("\n");

	update_med_price_repo(repo, "Ibuprofen", 5, 56);
	print_repo(repo);
	printf("\n");

	MedCtrl* ctrl = create_ctrl(repo);

	update_med_price_repo(ctrl->repo, "Ibuprofen", 5, 99);
	print_repo(ctrl->repo);
	printf("\n");

	Medication* medication4;
	medication4 = create_medication("Brufen", 12, 55, 7);

	add_med_repo(ctrl->repo, medication4);
	print_repo(ctrl->repo);
	printf("\n");

	MedRepo* repo2 = filter(ctrl, "fen");
	print_repo(repo2);
	free(repo2);

	printf("\n");

	print_repo(ctrl->repo);
	printf("\n");

	tests_repo();
	tests_controller();

	UI* ui = create_ui(ctrl);

	start_ui(ui);

	delete_ui(ui);

	_CrtDumpMemoryLeaks();

}