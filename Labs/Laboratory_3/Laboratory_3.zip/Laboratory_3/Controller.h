#pragma once
#include "Repo.h"

typedef struct {
	MedRepo* repo;
} MedCtrl;

MedCtrl* create_ctrl(MedRepo* repo);

void delete_ctrl(MedCtrl* ctrl);

MedRepo* filter(MedCtrl* ctrl, char String[]);

MedRepo* filter_price(MedCtrl* ctrl, int price);

MedRepo* short_supply(MedCtrl* ctrl, int quantity, int kind);

void tests_controller();

void test_filter();

void test_filter_price();

void test_short_supply();

//void set_repo(MedCtrl* ctrl, MedRepo* repo);

//void filter(MedCtrl* ctrl, char String[]);