#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Domain.h"

Medication* create_medication(char* name, int* concentration, int* quantity, int* price) {
	Medication *medication = malloc(sizeof(Medication));
	strcpy(medication->name, name);
	(*medication).concentration = concentration;
	(*medication).quantity = quantity;
	(*medication).price = price;
	return medication;
}

void delete_medication(Medication *medication) {
	free(medication);
}

char* get_name(Medication *medication) {
	return medication->name;
}

int* get_concentration(Medication *medication) {
	return medication->concentration;
}

int* get_quantity(Medication *medication) {
	return medication->quantity;
}

int* get_price(Medication *medication) {
	return medication->price;
}
