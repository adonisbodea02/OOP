#include "Repo.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

MedRepo* create_repo() {
	MedRepo* repo = (MedRepo*)malloc(sizeof(MedRepo));
	repo->length = 0;
	return repo;
}
void delete_repo(MedRepo* repo) {
	int i = 0;
	for (i = 0; i < repo->length; i++)
		delete_medication(repo->vect[i]);
	free(repo);
}

int add_med_repo(MedRepo* repo, Medication* med) {
	for(int i=0; i < repo->length; i++)
		if (repo->vect[i]->concentration == get_concentration(med))
			if (strcmp(repo->vect[i]->name, get_name(med)) == 0)
			{
				int q = get_quantity(med);
				repo->vect[i]->quantity = repo->vect[i]->quantity + q;
				return 0;
			}

	repo->vect[repo->length] = med;
	repo->length++;
	return 1;
}

int delete_med_repo(MedRepo* repo, char name[], int concentration) {
	for(int i = 0; i < repo->length; i++)
		if(repo->vect[i]->concentration == concentration)
			if (strcmp(repo->vect[i]->name, name) == 0)
			{
				delete_medication(repo->vect[i]);
				for(int j = i; j < repo->length - 1; j++)
					repo->vect[j] = repo->vect[j + 1];
				repo->length--;
				return 1;
			}

	return 0;
}

int update_med_quantity_repo(MedRepo* repo, char name[], int concentration, int new_quantity) {
	for (int i = 0; i < repo->length; i++)
		if (repo->vect[i]->concentration == concentration)
			if (strcmp(repo->vect[i]->name, name) == 0)
			{
				repo->vect[i]->quantity = new_quantity;
				return 1;
			}

	return 0;
}

int update_med_price_repo(MedRepo* repo, char name[], int concentration, int new_price) {
	for (int i = 0; i < repo->length; i++)
		if (repo->vect[i]->concentration == concentration)
			if (strcmp(repo->vect[i]->name, name) == 0)
			{
				repo->vect[i]->price = new_price;
				return 1;
			}
	return 0;
}

void print_repo(MedRepo* repo) {
	for(int i = 0; i < repo->length; i++)
		printf("%s %d %d %d\n", get_name(repo->vect[i]), get_concentration(repo->vect[i]), get_quantity(repo->vect[i]), get_price(repo->vect[i]));
}

int get_length_repo(MedRepo* repo) {
	return repo->length;
}

void test_add() {
	MedRepo* repo = create_repo();
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	assert(get_length_repo(repo) == 0);
	assert(add_med_repo(repo, medication) == 1);
	assert(get_length_repo(repo) == 1);
	assert(add_med_repo(repo, medication) == 0);
	assert(get_length_repo(repo) == 1);
	delete_repo(repo);
}

void test_delete() {
	MedRepo* repo = create_repo();
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	add_med_repo(repo, medication);
	assert(delete_med_repo(repo, "Nurofen", 13) == 0);
	assert(delete_med_repo(repo, "Nurof", 12) == 0);
	assert(delete_med_repo(repo, "Nurofen", 12) == 1);
	assert(get_length_repo(repo) == 0);
	delete_repo(repo);
}

void test_update_quantity() {
	MedRepo* repo = create_repo();
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	add_med_repo(repo, medication);
	assert(update_med_quantity_repo(repo, "Nurofen", 13, 56) == 0);
	assert(update_med_quantity_repo(repo, "Nurof", 12, 47) == 0);
	assert(update_med_quantity_repo(repo, "Nurofen", 12, 70) == 1);
	assert(get_quantity(repo->vect[0]) == 70);
	delete_repo(repo);
}

void test_update_price() {
	MedRepo* repo = create_repo();
	Medication* medication;
	medication = create_medication("Nurofen", 12, 5, 7);
	add_med_repo(repo, medication);
	assert(update_med_price_repo(repo, "Nurofen", 13, 56) == 0);
	assert(update_med_price_repo(repo, "Nurof", 12, 47) == 0);
	assert(update_med_price_repo(repo, "Nurofen", 12, 70) == 1);
	assert(get_price(repo->vect[0]) == 70);
	delete_repo(repo);
}

void tests_repo() {
	test_add();
	test_delete();
	test_update_quantity();
	test_update_price();
}