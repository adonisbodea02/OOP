#include "Vegetable.h"

Vegetable::Vegetable(std::string family, std::string name, std::string type)
{
	this->family = family;
	this->name = name;
	this->type = type;
}
